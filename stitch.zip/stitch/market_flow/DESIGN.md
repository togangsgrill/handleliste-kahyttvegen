# Design System Document: The Fluid Pantry

## 1. Overview & Creative North Star
**Creative North Star: "The Botanical Concierge"**
The digital grocery experience often feels like a sterile spreadsheet or a chaotic flyer. This design system rejects both. Our North Star, "The Botanical Concierge," balances high-efficiency utility with an organic, premium warmth. 

We break the "standard app" mold by moving away from rigid boxes and harsh lines. Instead, we utilize **Tonal Architecture**—a method where hierarchy is defined by soft shifts in color and depth rather than structural borders. The interface should feel like a series of soft, organized layers that "breathe," providing a low-friction environment for busy families navigating a physical store. We use intentional asymmetry in header layouts and generous whitespace to ensure the UI feels editorial and high-end, never "default."

---

## 2. Colors: Tonal Architecture
Our palette centers on a lush, professional green spectrum. We avoid the "tech-fluorescent" look in favor of sophisticated, nature-inspired tones.

### The Rules of Engagement
*   **The "No-Line" Rule:** 1px solid borders are strictly prohibited for sectioning. Contrast and containment must be achieved through background shifts. For example, a `surface-container-low` card sitting on a `surface` background provides all the definition needed.
*   **Surface Hierarchy & Nesting:** Treat the UI as physical layers. Use `surface-container-lowest` (#ffffff) for the most prominent interactive elements (like an active grocery item) and `surface-container-high` (#a7f1d8) for grouped background sections.
*   **The "Glass & Gradient" Rule:** Floating action buttons or headers should utilize Glassmorphism. Use `surface` colors at 80% opacity with a `20px` backdrop blur to allow the vibrant greens of the content to bleed through softly.
*   **Signature Textures:** Apply a subtle linear gradient (Top-Left to Bottom-Right) from `primary` (#006947) to `primary-container` (#00feb2) on main CTAs to give them a "jewel-like" depth that feels premium.

---

## 3. Typography: The Editorial Voice
We use a dual-font system to balance personality with extreme legibility.

*   **Display & Headlines (Plus Jakarta Sans):** Chosen for its modern, geometric clarity with a friendly touch. Use `display-lg` for empty states and `headline-sm` for category titles. The generous x-height ensures readability even while walking through a grocery aisle.
*   **Body & Titles (Manrope):** A highly functional sans-serif. `body-lg` is the workhorse for grocery list items, ensuring that even under harsh supermarket lighting, text remains crisp.
*   **Hierarchy as Authority:** Use `title-lg` for product names and `label-md` in `on-surface-variant` (#2f6555) for secondary metadata like weight or price per unit.

---

## 4. Elevation & Depth: The Layering Principle
Shadows are not "darkness"; they are the absence of light between two organic surfaces.

*   **Tonal Layering:** Instead of a shadow, place a `surface-container-lowest` card on a `surface-container` background. This "Soft Lift" is our primary method of elevation.
*   **Ambient Shadows:** For high-priority floating elements (e.g., a "Add to Cart" sticky bar), use a multi-layered shadow: `0px 10px 30px rgba(0, 54, 42, 0.06)`. Note the use of the `on-surface` color (#00362a) instead of pure black to keep the shadow "organic."
*   **The "Ghost Border" Fallback:** If accessibility requires a stroke, use the `outline-variant` (#81b8a5) at **15% opacity**. It should be felt, not seen.
*   **Glassmorphism:** Use for persistent navigation bars. This maintains the "Botanical" feel, suggesting a frosted glass pane over a garden.

---

## 5. Components
Our components are rounded and inviting, utilizing the `xl` (1.5rem) scale for major containers and `md` (0.75rem) for interactive elements.

*   **The "Smart" Shopping Card:** No dividers. Use `surface-container-low` for the card body. Use `title-md` for the item name. Separate the "Quantity" selector using a `surface-container-highest` background to create a "nested" look.
*   **Primary Buttons:** Use the signature gradient (Primary to Primary-Container). Use `full` (9999px) corner radius. Typography should be `label-md` in `on-primary`.
*   **Checkboxes:** When checked, the checkbox should transform into a `primary` circle with a `surface` checkmark. The entire list item should transition to a 40% opacity to visually "retire" the item without removing it.
*   **Input Fields:** Ghost-style inputs. Use `surface-container-highest` with no border. On focus, transition to a `1px` stroke of `primary` at 30% opacity.
*   **Floating Pantry Chips:** Use for "Frequently Bought" items. High-contrast `secondary-container` (#5afcd2) backgrounds with `on-secondary-container` (#005d4a) text.
*   **The "Contextual Header":** An asymmetrical header using `display-sm` that collapses into a glassmorphic sticky bar as the user scrolls.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use `surface-container` tiers to create hierarchy.
*   **Do** prioritize `body-lg` for any text meant to be read while moving.
*   **Do** use the `xl` corner radius for large containers to maintain the "friendly" brand personality.
*   **Do** use white space as a separator. If you feel you need a line, add 8px more padding instead.

### Don’t:
*   **Don't** use 100% black (#000000) for text; always use `on-surface` (#00362a) to maintain tonal harmony.
*   **Don't** use standard "drop shadows." If it looks like a default UI kit, increase the blur and decrease the opacity.
*   **Don't** use hard 90-degree corners. Everything in the pantry is organic and soft.
*   **Don't** use dividers in lists. If items feel cluttered, increase the `surface-variant` contrast between the row and the background.